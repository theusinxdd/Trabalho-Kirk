using System;
using System.Drawing;
using System.Windows.Forms;

namespace CalculadoraFisica
{
    // ===================== TELA INICIAL =====================
    public class MenuForm : Form
    {
        public MenuForm()
        {
            Text = "Calculadora de Física";
            ClientSize = new Size(360, 380);
            StartPosition = FormStartPosition.CenterScreen;
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;

            var titulo = new Label
            {
                Text = "Escolha uma fórmula",
                Font = new Font("Segoe UI", 14, FontStyle.Bold),
                AutoSize = false,
                TextAlign = ContentAlignment.MiddleCenter,
                Dock = DockStyle.Top,
                Height = 50
            };
            Controls.Add(titulo);

            AddBotao("1 - Velocidade Média", 60, () => new CalcForm(
                "Velocidade Média", "Vm = ΔS / Δt",
                new[] { "Variação de espaço ΔS (m)", "Variação de tempo Δt (s)" },
                v => $"Vm = {v[0] / v[1]:0.####} m/s", false).ShowDialog());

            AddBotao("2 - Aceleração", 110, () => new CalcForm(
                "Aceleração", "a = ΔV / Δt",
                new[] { "Variação de velocidade ΔV (m/s)", "Variação de tempo Δt (s)" },
                v => $"a = {v[0] / v[1]:0.####} m/s²", false).ShowDialog());

            AddBotao("3 - Força", 160, () => new CalcForm(
                "Força", "F = m · a",
                new[] { "Massa m (kg)", "Aceleração a (m/s²)" },
                v => $"F = {v[0] * v[1]:0.####} N", false).ShowDialog());

            AddBotao("4 - Força de Atrito", 210, () => new CalcForm(
                "Força de Atrito", "Fat = μ · N",
                new[] { "Coeficiente de atrito μ", "Força normal N (N)" },
                v => $"Fat = {v[0] * v[1]:0.####} N", false).ShowDialog());

            AddBotao("5 - Peso", 260, () => new CalcForm(
                "Peso", "P = m · g",
                new[] { "Massa m (kg)", "Gravidade g (m/s²) - ex: 9,8" },
                v => $"P = {v[0] * v[1]:0.####} N", false).ShowDialog());

            AddBotao("6 - Lei de Ohm", 310, () => new CalcForm(
                "Lei de Ohm", "V = R · I   (deixe vazio o campo que quer descobrir)",
                new[] { "Tensão V (volts)", "Resistência R (ohms)", "Corrente I (ampères)" },
                v =>
                {
                    int vazios = 0;
                    foreach (var x in v) if (x == null) vazios++;
                    if (vazios != 1) return "Deixe exatamente UM campo vazio.";

                    if (v[0] == null) return $"V = {v[1] * v[2]:0.####} V";
                    if (v[1] == null) return $"R = {v[0] / v[2]:0.####} Ω";
                    return $"I = {v[0] / v[1]:0.####} A";
                }, true).ShowDialog());
        }

        private void AddBotao(string texto, int top, Action abrir)
        {
            var b = new Button
            {
                Text = texto,
                Left = 50,
                Top = top,
                Width = 260,
                Height = 40,
                Font = new Font("Segoe UI", 11)
            };
            b.Click += (s, e) => abrir();
            Controls.Add(b);
        }
    }

    // ===================== TELA DE CÁLCULO (reutilizada) =====================
    public class CalcForm : Form
    {
        private readonly TextBox[] caixas;
        private readonly Label resultado;
        private readonly Func<double?[], string> calcular;
        private readonly bool permiteVazio;

        public CalcForm(string titulo, string formula, string[] campos,
                        Func<double?[], string> calcular, bool permiteVazio)
        {
            this.calcular = calcular;
            this.permiteVazio = permiteVazio;

            Text = titulo;
            StartPosition = FormStartPosition.CenterParent;
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;
            MinimizeBox = false;
            ClientSize = new Size(380, 150 + campos.Length * 60 + 80);

            Controls.Add(new Label
            {
                Text = titulo,
                Font = new Font("Segoe UI", 14, FontStyle.Bold),
                Left = 20,
                Top = 15,
                Width = 340,
                Height = 28
            });
            Controls.Add(new Label
            {
                Text = formula,
                Font = new Font("Segoe UI", 10, FontStyle.Italic),
                Left = 20,
                Top = 48,
                Width = 340,
                Height = 36
            });

            caixas = new TextBox[campos.Length];
            int y = 95;
            for (int i = 0; i < campos.Length; i++)
            {
                Controls.Add(new Label { Text = campos[i], Left = 20, Top = y, Width = 340 });
                caixas[i] = new TextBox { Left = 20, Top = y + 22, Width = 340 };
                Controls.Add(caixas[i]);
                y += 60;
            }

            var btnCalc = new Button { Text = "Calcular", Left = 20, Top = y, Width = 165, Height = 36 };
            btnCalc.Click += (s, e) => Calcular();
            Controls.Add(btnCalc);

            var btnVoltar = new Button { Text = "Voltar", Left = 195, Top = y, Width = 165, Height = 36 };
            btnVoltar.Click += (s, e) => Close();
            Controls.Add(btnVoltar);

            resultado = new Label
            {
                Left = 20,
                Top = y + 50,
                Width = 340,
                Height = 40,
                Font = new Font("Segoe UI", 12, FontStyle.Bold),
                ForeColor = Color.DarkGreen
            };
            Controls.Add(resultado);

            AcceptButton = btnCalc;
        }

        private void Calcular()
        {
            var valores = new double?[caixas.Length];
            for (int i = 0; i < caixas.Length; i++)
            {
                string txt = caixas[i].Text.Trim();
                if (txt == "")
                {
                    if (!permiteVazio) { Erro("Preencha todos os campos."); return; }
                    valores[i] = null;
                }
                else if (double.TryParse(txt, out double n))
                {
                    valores[i] = n;
                }
                else
                {
                    Erro("Digite apenas números (use vírgula para decimais).");
                    return;
                }
            }

            try
            {
                string r = calcular(valores);
                if (r.Contains("Infinito") || r.Contains("∞") || r.Contains("NaN"))
                    Erro("Divisão por zero não é permitida.");
                else
                {
                    resultado.ForeColor = Color.DarkGreen;
                    resultado.Text = r;
                }
            }
            catch (Exception)
            {
                Erro("Não foi possível calcular.");
            }
        }

        private void Erro(string msg)
        {
            resultado.ForeColor = Color.Firebrick;
            resultado.Text = msg;
        }
    }

    // ===================== PONTO DE ENTRADA =====================
    internal static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new MenuForm());
        }
    }
}